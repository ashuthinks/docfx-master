﻿# [Getting Started](docfx_getting_started.md)
# [Engineering Guidelines](engineering_guidelines.md)
# [CSharp Coding Standards](csharp_coding_standards.md)