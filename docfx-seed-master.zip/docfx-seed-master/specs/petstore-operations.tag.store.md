---
uid: petstore.swagger.io/v2/Swagger Petstore/1.0.0/tag/store
---

Additional description for store tag