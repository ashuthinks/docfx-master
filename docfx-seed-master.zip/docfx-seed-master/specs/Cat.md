---
uid: CatLibrary.Cat`2
remarks: '*THIS* is remarks overridden in *MARKDWON* file'
---

This is a class talking about [CAT](https://en.wikipedia.org/wiki/Cat).

>**NOTE**
> This is a CAT class
>

Refer to @CatLibrary.IAnimal to see other animals.
