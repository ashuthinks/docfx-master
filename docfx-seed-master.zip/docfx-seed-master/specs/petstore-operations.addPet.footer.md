---
uid: petstore.swagger.io/v2/Swagger Petstore/1.0.0/addPet
footer: *content
---
> NOTE: Add pet only when you needs.
