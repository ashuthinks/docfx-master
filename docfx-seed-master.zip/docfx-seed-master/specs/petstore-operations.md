---
uid: petstore.swagger.io/v2/Swagger Petstore/1.0.0
title: Pet Store APIs
---

Describe APIs in Pet Store
