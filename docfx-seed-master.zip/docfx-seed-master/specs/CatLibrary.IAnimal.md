---
uid: CatLibrary.IAnimal
remarks: '*THIS* is remarks overridden in *MARKDWON* file'
---

### Welcome to the **Animal** world!
