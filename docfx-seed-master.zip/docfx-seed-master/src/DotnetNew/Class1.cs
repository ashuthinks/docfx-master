﻿using System;

namespace DotnetNew
{
    public class Class1
    {
    }
}
